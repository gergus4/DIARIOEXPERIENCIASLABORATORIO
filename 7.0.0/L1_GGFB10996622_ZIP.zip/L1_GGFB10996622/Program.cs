﻿
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre: ");
        string Nombre = Console.ReadLine();
        
        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy " + Nombre);

        /* La diferencia es que Console.Writline hace que se escriba todo en lineas distintas, 
         * es decir cada una de estas se encargará de separarlos, mietras que Console.Write, escribirá todo de corrido.*/ 

        Console.Write("Hola Mundo");
        Console.Write("soy " + Nombre);
        Console.ReadKey();
    }
}